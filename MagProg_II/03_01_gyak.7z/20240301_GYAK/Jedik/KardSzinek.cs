﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jedik {
    internal enum KardSzinek {
        ZOLD, KEK, LILA, SARGA, NARANCS, FEHER
    }
}
