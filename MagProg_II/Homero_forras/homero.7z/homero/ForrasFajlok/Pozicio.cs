class Pozicio
{
	public Pozicio(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	public int x { get; set; }
	public int y { get; set; }
}