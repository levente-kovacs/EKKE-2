﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Edesszajuak
{
    internal enum CsokoladeFajta
    {
        Kerek,
        Szogletes,
        Hosszu,
        Rovid,
        Gombolyu,
        Tej,
        Et
    }
}
